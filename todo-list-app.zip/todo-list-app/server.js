const express = require('express');
const app = express();
const port = 3000;

// Middleware para servir archivos estáticos (como HTML, CSS, JS)
app.use(express.static('public'));

// Ruta principal
app.get('/', (req, res) => {
  res.send('¡Hola, coders! Este es el servidor Express para el ToDo list.');
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
